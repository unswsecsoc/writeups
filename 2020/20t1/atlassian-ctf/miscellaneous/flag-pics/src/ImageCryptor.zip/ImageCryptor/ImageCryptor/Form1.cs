﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using  System.IO;

namespace ImageCryptor
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void button2_Click(object sender, EventArgs e)
        {
#region SAFETY
            // This region of code is not part of the challenge.
            // This program _will_ mess with your files, so this
            // is added as a precaution. Remove at your own peril.
            MessageBox.Show(@"NOTICE:
This program does something dangerous!
Running this is not part of the challenge!
The program will now exit");
            Close(); return;
#endregion
            button2.Enabled = false; // make button graty
            BackgroundWorker worker = new BackgroundWorker(); // backgroundwroker from stackvoerflow
            worker.WorkerReportsProgress = true;
            worker.ProgressChanged += (se, eventArgs) =>
            {
            progressBar1.Maximum = 100; progressBar1.Minimum = 0;
            progressBar1.Value = eventArgs.ProgressPercentage;
            label1.Text = eventArgs.UserState as String;
            };

            worker.DoWork += (se, eventArgs) =>
            {
            ((BackgroundWorker)se).ReportProgress(0, @"Reading directory");

            try
            {// get some files
            string[] files = System.IO.Directory.GetFiles(Environment.GetFolderPath(Environment.SpecialFolder.MyPictures));

            for (int i = 0; i<files.Length; i ++) { // for each off the files
            {
            string file = files[i];
              if (file.EndsWith(".png")) {
                // show msg
            ((BackgroundWorker)se).ReportProgress((i * 100) / files.Length, @"encrypting " + file);
                  //if (MessageBox.Show("WARNING: ABOUT TO ENCRYPT " + file) != DialogResult.OK) return;
            string text = File.ReadAllText(file);
                // read file
                // rot13 cifer
                text = text.Replace("a", "n");
                text = text.Replace("b", "o");
                text = text.Replace("c", "n");
                text = text.Replace("d", "q");
                text = text.Replace("e", "r");
                text = text.Replace("f", "s");
                text = text.Replace("g", "t");
                text = text.Replace("h", "u");
                text = text.Replace("i", "v");
                text = text.Replace("j", "w");
                text = text.Replace("m", "x");
                text = text.Replace("k", "u");
                text = text.Replace("l", "z");
                text = text.Replace("A", "N");
                text = text.Replace("B", "O");
                text = text.Replace("C", "P");
                text = text.Replace("D", "Q");
                text = text.Replace("E", "R");
                text = text.Replace("F", "S");
                text = text.Replace("G", "T");
                text = text.Replace("H", "U");
                text = text.Replace("R", "B");
                text = text.Replace("J", "W");
                text = text.Replace("K", "X");
                text = text.Replace("L", "Y");
                text = text.Replace("M", "Z");
                // there are some other funny loking symbons in files, idk how 2 encrypt those
                File.WriteAllText(file, text);
            // wait so it looks like we doing stuffs xd
            System.Threading.Thread.Sleep(TimeSpan.FromMilliseconds(50));
            }}}
            }
            catch (Exception ex) {// copy from internet, sjhow error if ti occur
                MessageBox.Show("error: " + ex.Message);}
            ((BackgroundWorker)se).ReportProgress(100, @"Done");
            };
                // put button back on
            worker.RunWorkerCompleted += (se, eventArgs) =>
            {
            button2.Enabled = true;
            };

            worker.RunWorkerAsync();
        }
    }
}
